import { Injectable } from '@nestjs/common';
import { Message } from '@encora-backend/api-interfaces';

@Injectable()
export class AppService {
  getData(): Message {
    return { message: 'Welcome to api!' };
  }
}
